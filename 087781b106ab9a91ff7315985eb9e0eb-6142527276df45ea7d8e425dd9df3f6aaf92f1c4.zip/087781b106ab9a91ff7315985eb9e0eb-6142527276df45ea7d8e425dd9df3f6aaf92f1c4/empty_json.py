import os 
import json


folder_name = '' # Directory name consisting images
os.chdir(folder_name)
json_file = dict()
json_file = {
    "textBBs": [],
    "fieldBBs": [],
    "pairs": [],
    "samePairs": []
}
for img_name in os.listdir():
    img_name = img_name.split('.')
    json_name = img_name[0]+'.json'
    with open(os.path.join(folder_name,json_name),'w') as new_f:
        json.dump(json_file,new_f)